package com.example.genearal_house_service_clients

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
