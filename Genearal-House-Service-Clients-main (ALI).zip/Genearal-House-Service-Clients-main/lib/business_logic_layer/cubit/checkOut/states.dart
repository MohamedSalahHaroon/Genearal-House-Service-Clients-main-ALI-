abstract class CheckOutStates {}

class InitialState extends CheckOutStates{}

class CheckedOutSuccess extends CheckOutStates{}

class CheckedOutFailed extends CheckOutStates{}

