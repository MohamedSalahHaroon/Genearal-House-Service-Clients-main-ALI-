abstract class UpdateProfileState{}

class InitialState extends UpdateProfileState{}

class UpdatedSuccessState extends UpdateProfileState{}

class UpdatedFailedState extends UpdateProfileState{}

