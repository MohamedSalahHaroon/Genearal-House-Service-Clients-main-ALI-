abstract class LogOutStates{}

class InitialState extends LogOutStates{}

class SuccessState extends LogOutStates{}

class FailedState extends LogOutStates{}

