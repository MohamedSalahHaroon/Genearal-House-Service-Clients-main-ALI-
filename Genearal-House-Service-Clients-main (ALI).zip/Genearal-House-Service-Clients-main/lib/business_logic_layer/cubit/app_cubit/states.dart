abstract class AppStates{}

class AppInitialState extends AppStates{}

class ChangeBottomNavBarState extends AppStates{}

class NavigateOnTapState extends AppStates{}
