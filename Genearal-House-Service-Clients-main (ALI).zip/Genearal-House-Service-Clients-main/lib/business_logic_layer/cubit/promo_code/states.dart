abstract class PromoCodeStates{}

class PromoCodeInitialState extends PromoCodeStates{}

class PromoCodeLoadingState extends PromoCodeStates{}

class PromoCodeSuccessState extends PromoCodeStates{}

class PromoCodeErrorState extends PromoCodeStates{}


